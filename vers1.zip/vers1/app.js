/* ═══════════════════════════════════════════════
   EsportsArena Mini App — Frontend Logic
   Vanilla JS, no frameworks
═══════════════════════════════════════════════ */

'use strict';

// ─── Telegram WebApp Init ─────────────────────────────────────────────────────
const tg = window.Telegram?.WebApp;
if (tg) {
  tg.ready();
  tg.expand();
}

const TG_USER   = tg?.initDataUnsafe?.user || null;
const USER_ID   = TG_USER?.id       || `guest_${Math.random().toString(36).slice(2,8)}`;
const USER_NAME = TG_USER?.username || TG_USER?.first_name || 'Гість';

document.getElementById('userName').textContent = `@${USER_NAME}`;
document.getElementById('userAvatar').textContent = USER_NAME.charAt(0).toUpperCase();

// ─── State ────────────────────────────────────────────────────────────────────
const STORAGE_KEY = `esports_predictions_${USER_ID}`;

function loadPredictionsFromStorage() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); } catch { return {}; }
}
function savePredictionsToStorage() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(myPredictions)); } catch {}
}
// We no longer prune predictions when matches disappear from the active list
// because finished matches are removed from /matches but still scored server-side.
// We only clean up truly orphaned entries (e.g. from old sessions with different IDs).
function pruneOrphanedPredictions(knownMatchIds) {
  // Don't prune — predictions for finished matches are still valid for leaderboard
  // Only auto-prune if we have a large backlog (>200 entries) to avoid storage bloat
  const keys = Object.keys(myPredictions);
  if (keys.length > 200) {
    const validSet = new Set(knownMatchIds);
    let changed = false;
    for (const matchId of keys) {
      if (!validSet.has(matchId)) { delete myPredictions[matchId]; changed = true; }
    }
    if (changed) savePredictionsToStorage();
  }
}

let myPredictions = loadPredictionsFromStorage();
let activeGame    = '';
let autoRefreshTimer = null;
let currentMatches   = [];

// ─── Helpers ─────────────────────────────────────────────────────────────────
function toast(msg, type = 'info') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  document.getElementById('toasts').appendChild(el);
  setTimeout(() => el.remove(), 3000);
}

function formatTime(iso) {
  const d   = new Date(iso);
  const now = new Date();
  const diff = d - now;
  if (Math.abs(diff) < 60000) return 'Зараз / Now';
  if (diff > 0) {
    const h = Math.floor(diff / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    if (h > 0) return `через ${h}г ${m}хв`;
    return `через ${m}хв`;
  }
  const ago = Math.abs(diff);
  const h = Math.floor(ago / 3600000);
  const m = Math.floor((ago % 3600000) / 60000);
  if (h > 0) return `${h}г ${m}хв тому`;
  return `${m}хв тому`;
}

function timeAgo(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1)  return 'щойно';
  if (m < 60) return `${m}хв тому`;
  return `${Math.floor(m/60)}г тому`;
}

const GAME_ICONS = {
  'CS2': '🔫', 'Dota 2': '🧙', 'Valorant': '🎯',
  'League of Legends': '⚔️', 'Apex Legends': '🪂',
};

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ─── TABS ─────────────────────────────────────────────────────────────────────
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const tab = btn.dataset.tab;
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(`tab-${tab}`).classList.add('active');
    if (tab === 'leaderboard') loadLeaderboard();
    if (tab === 'lfg')         loadPlayers();
  });
});

// ─── MATCHES ─────────────────────────────────────────────────────────────────
// Scored results from finished matches (fetched separately from server)
let myResults = []; // [{ matchId, pickedTeam, winnerTeam, correct, game }]

async function loadScoredResults() {
  try {
    const res = await fetch(`/results/${encodeURIComponent(USER_ID)}`);
    myResults = await res.json();
  } catch { /* silent */ }
}

async function loadMatches(silent = false) {
  if (!silent) {
    document.getElementById('matchesList').innerHTML =
      `<div class="empty-state"><span class="empty-icon">📡</span><div class="loading-dots"><span></span><span></span><span></span></div></div>`;
  }
  try {
    const [matchRes] = await Promise.all([
      fetch('/matches'),
      loadScoredResults(),
    ]);
    const matches = await matchRes.json();
    currentMatches = matches;
    pruneOrphanedPredictions(matches.map(m => m.id));
    renderMatches(matches);
    updateSourceBadge(matches);
  } catch (e) {
    if (!silent) {
      document.getElementById('matchesList').innerHTML =
        `<div class="empty-state"><span class="empty-icon">⚠️</span>Помилка завантаження / Load error</div>`;
    }
  }
}

function updateSourceBadge(matches) {
  const badge = document.getElementById('sourceBadge');
  if (!badge) return;
  const sources = [...new Set(matches.map(m => m.source).filter(Boolean))];
  const isDemo = sources.length === 0 || (sources.length === 1 && sources[0] === 'demo');

  const sourceLabel = {
    pandascore: 'PandaScore',
    opendota: 'OpenDota',
    demo: 'Demo',
  };

  if (isDemo) {
    badge.textContent = '⚠️ Demo data';
    badge.className   = 'source-badge mock';
    badge.title       = 'API недоступний — показані демо матчі';
  } else {
    const labels = sources.filter(s => s !== 'demo').map(s => sourceLabel[s] || s);
    badge.textContent = `📡 ${labels.join(' + ')}`;
    badge.className   = 'source-badge live';
    badge.title       = `Оновлено: ${new Date().toLocaleTimeString('uk-UA')}`;
  }
}

function renderMatches(matches) {
  const container = document.getElementById('matchesList');
  if (!matches.length) {
    container.innerHTML = `<div class="empty-state"><span class="empty-icon">📭</span>Матчів немає / No matches</div>`;
  } else {
    // Only live and upcoming (finished are hidden — handled by server)
    const live     = matches.filter(m => m.status === 'live');
    const upcoming = matches.filter(m => m.status === 'upcoming');

    let html = '';
    if (live.length) {
      html += `<p class="match-group-label live-label">🔴 LIVE</p>`;
      html += live.map(m => renderMatchCard(m)).join('');
    }
    if (upcoming.length) {
      html += `<p class="match-group-label">📅 Майбутні / Upcoming</p>`;
      html += upcoming.map(m => renderMatchCard(m)).join('');
    }
    container.innerHTML = html;
  }

  // Show scored results summary below matches
  renderScoredResults();
}

function renderScoredResults() {
  const container = document.getElementById('matchesList');
  if (!myResults.length) return;

  const correct = myResults.filter(r => r.correct).length;
  const total   = myResults.length;

  let html = `
    <p class="match-group-label dim-label">✅ Мої результати / My Results</p>
    <div class="results-summary">
      <span class="results-score">${correct} / ${total}</span>
      <span class="results-label">правильних прогнозів</span>
    </div>
  `;

  html += myResults.map(r => `
    <div class="result-card ${r.correct ? 'result-correct' : 'result-wrong'}">
      <span class="result-icon">${r.correct ? '✅' : '❌'}</span>
      <div class="result-info">
        <div class="result-pick">Ваш вибір: <strong>${escHtml(r.pickedTeam)}</strong></div>
        <div class="result-winner">Переможець: <strong>${escHtml(r.winnerTeam)}</strong></div>
        <div class="result-meta">${escHtml(r.game)}${r.tournament ? ' — ' + escHtml(r.tournament) : ''}</div>
      </div>
    </div>
  `).join('');

  container.insertAdjacentHTML('beforeend', html);
}

function renderMatchCard(m) {
  const isFinished = m.status === 'finished';
  const isLive     = m.status === 'live';
  const myPick     = myPredictions[m.id];
  const winner     = m.winner;

  const teamAClass = myPick === m.teamA.id
    ? isFinished ? (winner === m.teamA.id ? 'winner-correct' : 'winner-wrong') : 'selected'
    : '';
  const teamBClass = myPick === m.teamB.id
    ? isFinished ? (winner === m.teamB.id ? 'winner-correct' : 'winner-wrong') : 'selected'
    : '';

  const disabled = (isFinished || isLive || myPick) ? 'disabled' : '';

  let statusBadge = '';
  if (isLive)     statusBadge = `<span class="match-status-badge live">🔴 LIVE</span>`;
  if (isFinished) statusBadge = `<span class="match-status-badge finished">Завершено</span>`;

  // Рахунок для завершених / LIVE
  let scoreHtml = '';
  if (m.score && (isFinished || isLive)) {
    scoreHtml = `<div class="match-score">${m.score.a} — ${m.score.b}</div>`;
  }

  const savedMsg = myPick
    ? `<p class="prediction-saved visible">✓ Прогноз: ${myPick === m.teamA.id ? escHtml(m.teamA.name) : escHtml(m.teamB.name)}</p>`
    : `<p class="prediction-saved" id="saved-${m.id}"></p>`;

  // HLTV посилання
  const hltvLink = m.hltvUrl
    ? `<a class="hltv-link" href="${m.hltvUrl}" target="_blank" rel="noopener">HLTV ↗</a>`
    : '';

  // Переможець підказка для завершених
  let winnerHint = '';
  if (isFinished && winner) {
    const wName = winner === m.teamA.id ? m.teamA.name : m.teamB.name;
    winnerHint = `<div class="winner-hint">🏆 ${escHtml(wName)}</div>`;
  }

  return `
    <div class="match-card${isLive ? ' match-card--live' : ''}">
      <div class="match-meta">
        <span class="match-game-tag">${escHtml(m.game)}</span>
        ${m.tournament ? `<span class="match-tournament">${escHtml(m.tournament)}</span>` : ''}
        <span class="match-time">${isLive ? '🔴 Live' : formatTime(m.startTime)}</span>
        ${statusBadge}
        ${hltvLink}
      </div>
      ${scoreHtml}
      <div class="teams-row">
        <button class="team-btn ${teamAClass}" ${disabled}
          onclick="predict('${m.id}','${m.teamA.id}','${escHtml(m.teamA.name)}')">
          <span class="team-logo">${m.teamA.logo}</span>
          <span class="team-name">${escHtml(m.teamA.name)}</span>
        </button>
        <span class="vs-divider">VS</span>
        <button class="team-btn ${teamBClass}" ${disabled}
          onclick="predict('${m.id}','${m.teamB.id}','${escHtml(m.teamB.name)}')">
          <span class="team-logo">${m.teamB.logo}</span>
          <span class="team-name">${escHtml(m.teamB.name)}</span>
        </button>
      </div>
      ${winnerHint}
      ${savedMsg}
    </div>
  `;
}

async function predict(matchId, teamId, teamName) {
  if (myPredictions[matchId]) return;
  myPredictions[matchId] = teamId;
  savePredictionsToStorage();

  try {
    const res = await fetch('/predict', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: USER_ID, username: USER_NAME, matchId, teamId }),
    });
    const data = await res.json();
    if (!data.success) throw new Error(data.error || 'Server error');
    toast(`✅ Прогноз: ${teamName}`, 'success');
  } catch (err) {
    toast(`❌ Помилка збереження: ${err.message}`, 'error');
    delete myPredictions[matchId];
    savePredictionsToStorage();
  }
  renderMatches(currentMatches); // re-render locally
}

// ─── Auto refresh ─────────────────────────────────────────────────────────────
function startAutoRefresh() {
  // Оновлюємо матчі кожні 60 секунд (тихо)
  autoRefreshTimer = setInterval(() => {
    loadMatches(true); // silent=true — не показуємо спіннер
  }, 60 * 1000);
}

// ─── LEADERBOARD ─────────────────────────────────────────────────────────────
async function loadLeaderboard() {
  const body = document.getElementById('leaderboardBody');
  body.innerHTML = `<div class="lb-empty"><div class="loading-dots"><span></span><span></span><span></span></div></div>`;
  try {
    const res  = await fetch('/leaderboard');
    const data = await res.json();
    renderLeaderboard(data);
  } catch {
    body.innerHTML = `<div class="lb-empty">⚠️ Помилка / Error</div>`;
  }
}

function renderLeaderboard(data) {
  const body = document.getElementById('leaderboardBody');
  if (!data.length) {
    body.innerHTML = `<div class="lb-empty">Ще немає прогнозів / No predictions yet</div>`;
    return;
  }
  const medals = ['🥇','🥈','🥉'];
  body.innerHTML = data.map((p, i) => {
    const rankLabel = i < 3 ? medals[i] : `#${i+1}`;
    const rankClass = i < 3 ? `rank-${i+1}` : '';
    const isMe = p.userId == USER_ID;
    return `
      <div class="lb-row" style="${isMe ? 'background:rgba(0,212,255,0.04);' : ''}">
        <span class="lb-rank ${rankClass}">${rankLabel}</span>
        <span class="lb-user">${isMe ? '⭐ ' : ''}${escHtml(p.username)}</span>
        <span class="lb-correct">${p.correct}</span>
        <span class="lb-total">${p.total}</span>
      </div>
    `;
  }).join('');
}

// ─── LFG ─────────────────────────────────────────────────────────────────────
document.getElementById('lfgSubmit').addEventListener('click', async () => {
  const game = document.getElementById('lfgGame').value;
  const role = document.getElementById('lfgRole').value;
  const rank = document.getElementById('lfgRank').value;
  if (!game || !role || !rank) { toast('⚠️ Заповніть всі поля / Fill all fields', 'error'); return; }

  try {
    const res  = await fetch('/lfg', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: USER_ID, username: USER_NAME, game, role, rank }),
    });
    const data = await res.json();
    if (data.success) { toast('✅ Профіль додано / Profile added', 'success'); loadPlayers(); }
    else              toast(`❌ ${data.error}`, 'error');
  } catch { toast('❌ Помилка сервера / Server error', 'error'); }
});

async function loadPlayers() {
  const container = document.getElementById('playersList');
  container.innerHTML = `<div class="empty-state"><div class="loading-dots"><span></span><span></span><span></span></div></div>`;
  try {
    const url = activeGame ? `/players?game=${encodeURIComponent(activeGame)}` : '/players';
    const res  = await fetch(url);
    const data = await res.json();
    renderPlayers(data);
  } catch {
    container.innerHTML = `<div class="empty-state"><span class="empty-icon">⚠️</span>Помилка / Error</div>`;
  }
}

function renderPlayers(players) {
  const container = document.getElementById('playersList');
  if (!players.length) {
    container.innerHTML = `<div class="empty-state"><span class="empty-icon">👤</span>Гравців не знайдено / No players found</div>`;
    return;
  }
  container.innerHTML = players.map(p => {
    const icon = GAME_ICONS[p.game] || '🎮';
    const isMe = p.userId == USER_ID;
    return `
      <div class="player-card">
        <div class="player-avatar">${icon}</div>
        <div class="player-info">
          <div class="player-name">${isMe ? '⭐ ' : ''}${escHtml(p.username)}</div>
          <div class="player-tags">
            <span class="player-tag tag-game">${escHtml(p.game)}</span>
            <span class="player-tag tag-role">${escHtml(p.role)}</span>
            <span class="player-tag tag-rank">${escHtml(p.rank)}</span>
          </div>
        </div>
        <span class="player-time">${timeAgo(p.joinedAt)}</span>
      </div>
    `;
  }).join('');
}

document.querySelectorAll('.filter-chip').forEach(chip => {
  chip.addEventListener('click', () => {
    document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
    chip.classList.add('active');
    activeGame = chip.dataset.game;
    loadPlayers();
  });
});

// ─── Init ─────────────────────────────────────────────────────────────────────
loadMatches();
startAutoRefresh();
