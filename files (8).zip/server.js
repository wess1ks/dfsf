const express = require('express');
const path    = require('path');
const https   = require('https');
const http    = require('http');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ─── In-memory storage ────────────────────────────────────────────────────────
const predictions = {};   // { userId: { username, picks: { matchId: teamId } } }
const lfgPlayers  = [];

// ─── Match cache ──────────────────────────────────────────────────────────────
let cachedMatches   = [];
let lastFetchTime   = 0;
const CACHE_TTL_MS  = 5 * 60 * 1000; // 5 хвилин

// ─── HLTV Scraper ─────────────────────────────────────────────────────────────
// HLTV не має публічного API — парсимо HTML сторінку /matches

function fetchUrl(url, options = {}) {
  return new Promise((resolve, reject) => {
    const mod = url.startsWith('https') ? https : http;
    const req = mod.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'identity',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'Referer': 'https://www.google.com/',
        ...options.headers,
      },
      timeout: 15000,
    }, (res) => {
      // Follow redirects
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return fetchUrl(res.headers.location, options).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`HTTP ${res.statusCode} for ${url}`));
      }
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      res.on('error', reject);
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Request timeout')); });
  });
}

// Простий HTML-парсер для HLTV — без залежностей
function parseHLTVMatches(html) {
  const matches = [];

  // Беремо всі блоки матчів
  const matchBlockRegex = /<div[^>]+class="[^"]*(?:upcoming-match|live-match|result-con)[^"]*"[^>]*>([\s\S]*?)<\/div>\s*(?=<div[^>]+class="[^"]*(?:upcoming-match|live-match|result-con|matches-table)[^"]*"|<\/section>)/g;

  // Альтернативний підхід — шукаємо посилання на матчі
  const matchLinkRegex = /href="(\/matches\/(\d+)\/[^"]+)"[^>]*>([\s\S]*?)(?=href="\/matches\/\d+\/|$)/g;

  let m;
  const seen = new Set();

  while ((m = matchLinkRegex.exec(html)) !== null) {
    const [, url, matchId, block] = m;
    if (seen.has(matchId)) continue;
    seen.add(matchId);

    // Витягуємо команди
    const teams = [];
    const teamRegex = /class="[^"]*team[^"]*"[^>]*>\s*(?:<img[^>]*alt="([^"]+)"|([^<\n]{2,30}))\s*</g;
    let t;
    const teamNames = [];

    // Простіший спосіб — шукаємо назви команд
    const teamNameMatches = block.matchAll(/(?:team1|team2)[^>]*>\s*([\w\s\.\-]+?)\s*</g);
    for (const tn of teamNameMatches) {
      if (tn[1].trim().length > 0) teamNames.push(tn[1].trim());
    }

    // Якщо не знайшли — пропускаємо
    if (teamNames.length < 2) continue;

    // Статус матчу
    let status = 'upcoming';
    let winner = null;
    if (/result-con/i.test(block) || /class="[^"]*result[^"]*"/i.test(block)) {
      status = 'finished';
    }
    if (/class="[^"]*live[^"]*"/i.test(block) || /LIVE/i.test(block)) {
      status = 'live';
    }

    // Час
    let startTime = new Date(Date.now() + 2 * 3600000).toISOString();
    const timeMatch = block.match(/data-unix="(\d+)"/);
    if (timeMatch) {
      startTime = new Date(parseInt(timeMatch[1])).toISOString();
    }

    // Рахунок для завершених
    let score = null;
    const scoreMatch = block.match(/(\d+)\s*[-:]\s*(\d+)/);
    if (scoreMatch && status === 'finished') {
      const s1 = parseInt(scoreMatch[1]);
      const s2 = parseInt(scoreMatch[2]);
      score = { a: s1, b: s2 };
      winner = s1 > s2 ? `hltv_${matchId}_a` : `hltv_${matchId}_b`;
    }

    const game = detectGame(block, url);

    matches.push({
      id: `hltv_${matchId}`,
      hltvId: matchId,
      hltvUrl: `https://www.hltv.org${url}`,
      game,
      teamA: {
        id: `hltv_${matchId}_a`,
        name: teamNames[0] || 'Team A',
        logo: gameEmoji(game),
      },
      teamB: {
        id: `hltv_${matchId}_b`,
        name: teamNames[1] || 'Team B',
        logo: gameEmoji(game),
      },
      startTime,
      status,
      winner,
      score,
    });

    if (matches.length >= 20) break;
  }

  return matches;
}

function detectGame(block, url) {
  const text = (block + url).toLowerCase();
  if (text.includes('dota'))     return 'Dota 2';
  if (text.includes('valorant')) return 'Valorant';
  if (text.includes('lol') || text.includes('league-of-legends')) return 'League of Legends';
  if (text.includes('apex'))     return 'Apex Legends';
  return 'CS2'; // HLTV переважно CS
}

function gameEmoji(game) {
  const map = {
    'CS2': '🔫', 'Dota 2': '🧙', 'Valorant': '🎯',
    'League of Legends': '⚔️', 'Apex Legends': '🪂',
  };
  return map[game] || '🎮';
}

// ─── HLTV fetch з fallback ────────────────────────────────────────────────────
async function fetchHLTVMatches() {
  const urls = [
    'https://www.hltv.org/matches',
    'https://hltv.org/matches',
  ];

  for (const url of urls) {
    try {
      console.log(`[HLTV] Fetching ${url}...`);
      const html = await fetchUrl(url);

      if (!html || html.length < 1000) {
        console.warn('[HLTV] Response too short, skipping');
        continue;
      }

      // Перевіряємо чи не потрапили на Cloudflare challenge
      if (html.includes('cf-browser-verification') || html.includes('Just a moment')) {
        console.warn('[HLTV] Cloudflare challenge detected');
        continue;
      }

      const parsed = parseHLTVMatches(html);
      if (parsed.length > 0) {
        console.log(`[HLTV] ✅ Parsed ${parsed.length} matches`);
        return parsed;
      }

      // Fallback: спробуємо альтернативний парсинг
      const fallback = parseHLTVFallback(html);
      if (fallback.length > 0) {
        console.log(`[HLTV] ✅ Fallback parsed ${fallback.length} matches`);
        return fallback;
      }

      console.warn('[HLTV] No matches found in HTML');
    } catch (err) {
      console.error(`[HLTV] Error fetching ${url}:`, err.message);
    }
  }

  return null; // Всі спроби провалились
}

// Fallback парсер — більш агресивний
function parseHLTVFallback(html) {
  const matches = [];
  const seen = new Set();

  // Шукаємо будь-які посилання на матчі
  const re = /href="\/matches\/(\d+)\/([^"]+)"/g;
  let m;
  const matchIds = [];

  while ((m = re.exec(html)) !== null) {
    const [, id, slug] = m;
    if (!seen.has(id)) {
      seen.add(id);
      matchIds.push({ id, slug });
    }
  }

  // Для кожного знайденого ID намагаємось витягнути контекст
  for (const { id, slug } of matchIds.slice(0, 15)) {
    // Витягуємо блок навколо посилання
    const idx = html.indexOf(`/matches/${id}/`);
    if (idx === -1) continue;
    const block = html.slice(Math.max(0, idx - 500), idx + 1000);

    // Шукаємо назви команд різними способами
    const teamNames = [];

    // Спосіб 1: team-name клас
    const tn1 = [...block.matchAll(/class="[^"]*team-name[^"]*"[^>]*>([^<]+)</g)];
    tn1.forEach(t => { if (t[1].trim()) teamNames.push(t[1].trim()); });

    // Спосіб 2: alt тег зображень команд
    const tn2 = [...block.matchAll(/alt="([^"]+(?:Gaming|Esports|Club|Team|FC|TL|NaVi|NAVI|Vitality|Liquid|Astralis|G2|FaZe|NIP|Heroic|ENCE|Complexity|BIG|Fnatic|MOUZ|Spirit|Cloud9|C9|Virtus)[^"]*)"/)];
    tn2.forEach(t => { if (t[1].trim()) teamNames.push(t[1].trim()); });

    // Спосіб 3: slug
    if (teamNames.length < 2) {
      const parts = slug.replace(/-vs-|-vs$/i, '|||').split('|||');
      if (parts.length === 2) {
        const nameFromSlug = s => s.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ').trim();
        if (parts[0]) teamNames.push(nameFromSlug(parts[0]));
        if (parts[1]) teamNames.push(nameFromSlug(parts[1].split('-')[0]));
      }
    }

    if (teamNames.length < 2) continue;

    const game = detectGame(block, slug);
    const isFinished = /result-con|class="[^"]*result[^"]*/i.test(block);
    const isLive = /\bLIVE\b/i.test(block);

    let status = isFinished ? 'finished' : (isLive ? 'live' : 'upcoming');
    let winner = null;
    let score = null;

    if (isFinished) {
      const sc = block.match(/(\d+)\s*[-:]\s*(\d+)/);
      if (sc) {
        const s1 = parseInt(sc[1]), s2 = parseInt(sc[2]);
        score = { a: s1, b: s2 };
        winner = s1 > s2 ? `hltv_${id}_a` : `hltv_${id}_b`;
      }
    }

    let startTime = new Date(Date.now() + 2 * 3600000).toISOString();
    const tm = block.match(/data-unix="(\d+)"/);
    if (tm) startTime = new Date(parseInt(tm[1])).toISOString();

    matches.push({
      id: `hltv_${id}`,
      hltvId: id,
      hltvUrl: `https://www.hltv.org/matches/${id}/${slug}`,
      game,
      teamA: { id: `hltv_${id}_a`, name: teamNames[0], logo: gameEmoji(game) },
      teamB: { id: `hltv_${id}_b`, name: teamNames[1], logo: gameEmoji(game) },
      startTime,
      status,
      winner,
      score,
    });
  }

  return matches;
}

// ─── Mock дані (fallback якщо HLTV недоступний) ───────────────────────────────
function getMockMatches() {
  console.log('[HLTV] Using mock data as fallback');
  return [
    {
      id: 'mock_1', game: 'CS2', source: 'mock',
      teamA: { id: 'mock_1_a', name: 'NAVI',          logo: '🏆' },
      teamB: { id: 'mock_1_b', name: 'Team Vitality',  logo: '🐝' },
      startTime: new Date(Date.now() + 1 * 3600000).toISOString(),
      status: 'upcoming', winner: null, score: null,
    },
    {
      id: 'mock_2', game: 'CS2', source: 'mock',
      teamA: { id: 'mock_2_a', name: 'G2 Esports',    logo: '⚡' },
      teamB: { id: 'mock_2_b', name: 'FaZe Clan',     logo: '💀' },
      startTime: new Date(Date.now() + 3 * 3600000).toISOString(),
      status: 'upcoming', winner: null, score: null,
    },
    {
      id: 'mock_3', game: 'CS2', source: 'mock',
      teamA: { id: 'mock_3_a', name: 'Heroic',        logo: '⚔️' },
      teamB: { id: 'mock_3_b', name: 'ENCE',          logo: '🎯' },
      startTime: new Date(Date.now() - 2 * 3600000).toISOString(),
      status: 'finished', winner: 'mock_3_a',
      score: { a: 2, b: 0 },
    },
    {
      id: 'mock_4', game: 'CS2', source: 'mock',
      teamA: { id: 'mock_4_a', name: 'Astralis',      logo: '🌟' },
      teamB: { id: 'mock_4_b', name: 'NIP',           logo: '🎮' },
      startTime: new Date(Date.now() + 5 * 3600000).toISOString(),
      status: 'upcoming', winner: null, score: null,
    },
    {
      id: 'mock_5', game: 'Dota 2', source: 'mock',
      teamA: { id: 'mock_5_a', name: 'Team Spirit',   logo: '👻' },
      teamB: { id: 'mock_5_b', name: 'OG',            logo: '🌿' },
      startTime: new Date(Date.now() + 6 * 3600000).toISOString(),
      status: 'upcoming', winner: null, score: null,
    },
  ];
}

// ─── Оновлення кешу ───────────────────────────────────────────────────────────
async function refreshMatchCache() {
  const now = Date.now();
  if (now - lastFetchTime < CACHE_TTL_MS && cachedMatches.length > 0) {
    return cachedMatches;
  }

  const live = await fetchHLTVMatches();

  if (live && live.length > 0) {
    // Зберігаємо стани прогнозів при оновленні кешу
    // (матчі що вже є в кеші — зберігаємо результати)
    const prevMap = {};
    cachedMatches.forEach(m => { prevMap[m.id] = m; });

    cachedMatches = live.map(m => {
      const prev = prevMap[m.id];
      // Якщо матч вже був finished і тепер знову прийшов — зберігаємо winner
      if (prev && prev.status === 'finished' && !m.winner) {
        return { ...m, status: 'finished', winner: prev.winner, score: prev.score };
      }
      return m;
    });

    cachedMatches.sort((a, b) => {
      const order = { live: 0, upcoming: 1, finished: 2 };
      return (order[a.status] ?? 1) - (order[b.status] ?? 1);
    });

    lastFetchTime = now;
    console.log(`[Cache] Updated: ${cachedMatches.length} matches, live=${cachedMatches.filter(m=>m.status==='live').length}`);
  } else {
    // Fallback на mock якщо кеш порожній
    if (cachedMatches.length === 0) {
      cachedMatches = getMockMatches();
    }
    lastFetchTime = now; // не спамимо запитами навіть при помилці
    console.warn('[Cache] Using existing/mock data due to fetch failure');
  }

  return cachedMatches;
}

// ─── Routes ───────────────────────────────────────────────────────────────────

// GET /matches
app.get('/matches', async (req, res) => {
  try {
    const matches = await refreshMatchCache();
    res.json(matches);
  } catch (err) {
    console.error('[GET /matches]', err);
    res.json(cachedMatches.length ? cachedMatches : getMockMatches());
  }
});

// GET /matches/status — легкий endpoint для перевірки змін без повного рефреша
app.get('/matches/status', async (req, res) => {
  const matches = cachedMatches.length ? cachedMatches : getMockMatches();
  res.json({
    count: matches.length,
    live: matches.filter(m => m.status === 'live').length,
    upcoming: matches.filter(m => m.status === 'upcoming').length,
    finished: matches.filter(m => m.status === 'finished').length,
    lastUpdate: new Date(lastFetchTime).toISOString(),
    source: matches[0]?.source === 'mock' ? 'mock' : 'hltv',
  });
});

// POST /predict  { userId, username, matchId, teamId }
app.post('/predict', (req, res) => {
  const { userId, username, matchId, teamId } = req.body;
  if (!userId || !matchId || !teamId)
    return res.status(400).json({ error: 'Missing fields' });

  const match = cachedMatches.find(m => m.id === matchId);
  if (!match) return res.status(404).json({ error: 'Match not found' });
  if (match.status === 'finished')
    return res.status(400).json({ error: 'Match already finished' });

  if (!predictions[userId]) predictions[userId] = { username, picks: {} };
  predictions[userId].username = username || predictions[userId].username || `User${userId}`;
  predictions[userId].picks[matchId] = teamId;

  res.json({ success: true, message: 'Прогноз збережено / Prediction saved' });
});

// GET /leaderboard
app.get('/leaderboard', (req, res) => {
  const board = Object.entries(predictions).map(([userId, data]) => {
    let correct = 0, total = 0;
    for (const [matchId, teamId] of Object.entries(data.picks)) {
      const match = cachedMatches.find(m => m.id === matchId);
      if (match && match.status === 'finished') {
        total++;
        if (match.winner === teamId) correct++;
      }
    }
    return { userId, username: data.username || `User${userId}`, correct, total };
  });
  board.sort((a, b) => b.correct - a.correct || b.total - a.total);
  res.json(board);
});

// POST /lfg  { userId, username, game, role, rank }
app.post('/lfg', (req, res) => {
  const { userId, username, game, role, rank } = req.body;
  if (!userId || !game || !role || !rank)
    return res.status(400).json({ error: 'Missing fields' });

  const existing = lfgPlayers.findIndex(p => p.userId === userId);
  const player = { userId, username: username || `User${userId}`, game, role, rank, joinedAt: new Date().toISOString() };

  if (existing !== -1) lfgPlayers[existing] = player;
  else lfgPlayers.push(player);

  res.json({ success: true, message: 'Профіль додано / Profile added' });
});

// GET /players?game=CS2
app.get('/players', (req, res) => {
  const { game } = req.query;
  res.json(game ? lfgPlayers.filter(p => p.game === game) : lfgPlayers);
});

// ─── Start + initial fetch ────────────────────────────────────────────────────
app.listen(PORT, async () => {
  console.log(`\n🎮 Esports Mini App running at http://localhost:${PORT}`);
  console.log(`📡 Fetching HLTV matches on startup...`);
  await refreshMatchCache();
  console.log(`✅ Ready! ${cachedMatches.length} matches loaded\n`);

  // Автооновлення кожні 5 хвилин
  setInterval(() => {
    lastFetchTime = 0; // форс-рефреш
    refreshMatchCache().catch(console.error);
  }, CACHE_TTL_MS);
});
