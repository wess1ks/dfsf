# ⚡ EsportsArena Telegram Mini App

Esports Match Predictions + Teammate Finder (LFG)  
Мова інтерфейсу: **Українська / English** (двомовний)

---

## 📁 Structure

```
telegram-esports-app/
├── server.js          ← Node.js + Express backend
├── package.json
├── README.md
└── public/
    ├── index.html     ← Main HTML (Telegram Mini App entry)
    ├── app.js         ← Frontend logic (vanilla JS)
    └── style.css      ← Dark esports UI styles
```

---

## 🚀 Quick Start

### 1. Install & Run

```bash
cd telegram-esports-app
npm install
node server.js
```

App runs at: `http://localhost:3000`

---

## 🌍 Expose with Cloudflare Tunnel (for Telegram)

Telegram Mini Apps require **HTTPS**. Use Cloudflare Tunnel to get a public HTTPS URL.

### Install cloudflared

```bash
# Ubuntu
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb -o cloudflared.deb
sudo dpkg -i cloudflared.deb
```

### Run Tunnel (no account needed)

```bash
cloudflared tunnel --url http://localhost:3000
```

You'll get a URL like:
```
https://your-random-subdomain.trycloudflare.com
```

Copy this URL — you need it for Telegram Bot setup.

---

## 📱 Connect to Telegram Bot

### Step 1 — Create a Bot

1. Open Telegram → search `@BotFather`
2. Send `/newbot` and follow the prompts
3. Copy your **Bot Token**

### Step 2 — Set Mini App URL

In BotFather, send:
```
/newapp
```

Or set a menu button:
```
/setmenubutton
```

Select your bot, then enter the Cloudflare URL:
```
https://your-random-subdomain.trycloudflare.com
```

### Step 3 — Open the Mini App

Either:
- Go to your bot in Telegram and tap the **Menu Button**
- Or use a direct link: `https://t.me/YourBotName/app`

---

## 🔌 API Endpoints

| Method | Endpoint      | Description                        |
|--------|---------------|------------------------------------|
| GET    | /matches      | List all matches                   |
| POST   | /predict      | Submit a prediction                |
| GET    | /leaderboard  | Prediction leaderboard             |
| POST   | /lfg          | Add/update LFG profile             |
| GET    | /players      | List LFG players (filter: ?game=)  |

### POST /predict
```json
{
  "userId": "123456",
  "username": "player1",
  "matchId": "m1",
  "teamId": "tA1"
}
```

### POST /lfg
```json
{
  "userId": "123456",
  "username": "player1",
  "game": "CS2",
  "role": "Sniper / AWPer",
  "rank": "Faceit 6-10"
}
```

---

## ⚙️ Run as systemd Service (Production)

```bash
sudo nano /etc/systemd/system/esports-app.service
```

```ini
[Unit]
Description=EsportsArena Telegram Mini App
After=network.target

[Service]
WorkingDirectory=/path/to/telegram-esports-app
ExecStart=/usr/bin/node server.js
Restart=always
Environment=PORT=3000

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable esports-app
sudo systemctl start esports-app
sudo systemctl status esports-app
```

---

## 📝 Notes

- Data is stored **in-memory** — restarting the server clears all predictions and LFG profiles
- Match results for finished matches are hardcoded in `server.js` (`matchResults` object)
- To mark a match as finished, update the `matches` array in `server.js` and set `status: 'finished'` and `winner: 'teamId'`
- For production: replace in-memory storage with SQLite or PostgreSQL
