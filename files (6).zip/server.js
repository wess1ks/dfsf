const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ─── In-memory storage ────────────────────────────────────────────────────────
const predictions = {}; // { userId: { matchId: teamId } }
const lfgPlayers  = [];
let   matchResults = {}; // { matchId: winnerId } — set manually for demo

// ─── Mock match data ──────────────────────────────────────────────────────────
const matches = [
  {
    id: 'm1',
    game: 'CS2',
    teamA: { id: 'tA1', name: 'NAVI',       logo: '🏆' },
    teamB: { id: 'tB1', name: 'Team Vitality', logo: '🐝' },
    startTime: new Date(Date.now() + 1 * 60 * 60 * 1000).toISOString(),
    status: 'upcoming',
  },
  {
    id: 'm2',
    game: 'Dota 2',
    teamA: { id: 'tA2', name: 'Team Spirit',  logo: '👻' },
    teamB: { id: 'tB2', name: 'OG',            logo: '🌿' },
    startTime: new Date(Date.now() + 3 * 60 * 60 * 1000).toISOString(),
    status: 'upcoming',
  },
  {
    id: 'm3',
    game: 'Valorant',
    teamA: { id: 'tA3', name: 'Sentinels',    logo: '🛡️' },
    teamB: { id: 'tB3', name: 'FNATIC',        logo: '🔶' },
    startTime: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
    status: 'finished',
    winner: 'tA3',
  },
  {
    id: 'm4',
    game: 'CS2',
    teamA: { id: 'tA4', name: 'G2 Esports',  logo: '⚡' },
    teamB: { id: 'tB4', name: 'FaZe Clan',   logo: '💀' },
    startTime: new Date(Date.now() + 5 * 60 * 60 * 1000).toISOString(),
    status: 'upcoming',
  },
  {
    id: 'm5',
    game: 'Dota 2',
    teamA: { id: 'tA5', name: 'PSG.LGD',     logo: '🐉' },
    teamB: { id: 'tB5', name: 'Evil Geniuses', logo: '🤖' },
    startTime: new Date(Date.now() + 7 * 60 * 60 * 1000).toISOString(),
    status: 'upcoming',
  },
];

// Pre-seed finished match result
matchResults['m3'] = 'tA3';

// ─── Routes ───────────────────────────────────────────────────────────────────

// GET /matches
app.get('/matches', (req, res) => {
  res.json(matches);
});

// POST /predict  { userId, username, matchId, teamId }
app.post('/predict', (req, res) => {
  const { userId, username, matchId, teamId } = req.body;
  if (!userId || !matchId || !teamId) {
    return res.status(400).json({ error: 'Missing fields' });
  }

  const match = matches.find(m => m.id === matchId);
  if (!match) return res.status(404).json({ error: 'Match not found' });
  if (match.status === 'finished') {
    return res.status(400).json({ error: 'Match already finished' });
  }

  if (!predictions[userId]) predictions[userId] = { username, picks: {} };
  predictions[userId].username = username || predictions[userId].username || `User${userId}`;
  predictions[userId].picks[matchId] = teamId;

  res.json({ success: true, message: 'Прогноз збережено / Prediction saved' });
});

// GET /leaderboard
app.get('/leaderboard', (req, res) => {
  const board = Object.entries(predictions).map(([userId, data]) => {
    let correct = 0, total = 0;
    for (const [matchId, teamId] of Object.entries(data.picks)) {
      const match = matches.find(m => m.id === matchId);
      if (match && match.status === 'finished') {
        total++;
        if (match.winner === teamId) correct++;
      }
    }
    return { userId, username: data.username || `User${userId}`, correct, total };
  });

  board.sort((a, b) => b.correct - a.correct || b.total - a.total);
  res.json(board);
});

// POST /lfg  { userId, username, game, role, rank }
app.post('/lfg', (req, res) => {
  const { userId, username, game, role, rank } = req.body;
  if (!userId || !game || !role || !rank) {
    return res.status(400).json({ error: 'Missing fields' });
  }

  const existing = lfgPlayers.findIndex(p => p.userId === userId);
  const player = {
    userId,
    username: username || `User${userId}`,
    game,
    role,
    rank,
    joinedAt: new Date().toISOString(),
  };

  if (existing !== -1) lfgPlayers[existing] = player;
  else lfgPlayers.push(player);

  res.json({ success: true, message: 'Профіль додано / Profile added' });
});

// GET /players?game=CS2
app.get('/players', (req, res) => {
  const { game } = req.query;
  const result = game
    ? lfgPlayers.filter(p => p.game === game)
    : lfgPlayers;
  res.json(result);
});

// ─── Start ────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🎮 Esports Mini App running at http://localhost:${PORT}`);
  console.log(`📱 Open in Telegram or browser`);
});
